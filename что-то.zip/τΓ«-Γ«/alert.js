/* var name = prompt("Как вас зовут?", "");
alert("Ваше имя " + name);
var company = prompt ("Каково официальное название JavaScript", ' ');
if (company == 'ECMAScript') {
  alert("Верно!");
} else {
  alert("Не знаете? ECMAScript!");
}

var adminPass = prompt("Кто пришел?");

if (adminPass == "Админ") {
  var pass = prompt("Пароль?", " ");

  if (pass == "Черный Властелин") {
    alert("Добро пожаловать!");
  } else if (pass == null) {
    alert("Вход отменен");
  } else {
    alert("Пароль не верен");
  }
} else if (adminPass == null) {
  alert("Вход отменен")
} else {
  alert('Я вас не знаю')
}


var i = 3;

while (i) {
  alert( --i);
} // есть разница при смени --i (вызывает старое число) и i--(вызывает новое число)

for (var i = 0; i < 5; ++i)
alert( i );
// нет ни какой разници, можно писать ++i и i++
for (var i = 0; i < 5; i++)
alert( i );

for (var i = 2; i < 10; i++) {
  if (i % 3 == 0) continue;
  alert(i);
}

var i = 0;
while (i < 3) {
  alert( "номер " + i + "!" );
  i++;
} // если i++ поставить впреди alert, то счет пойдет с 1.

nextPrime:
  for (var i = 2; i <= 10; i++) {

    for (var j = 2; j < i; j++) {
      if (i % j == 0) continue nextPrime;
    }

    alert( i ); // простое
  }

var n = 0;
metaO:
  while (n <= 5) {
    for (var i = 0; i <= 10; i++) {
    n += i;
    }
    alert(n);
}

function min(a, b) {
  if (a <= b) {
    return(a);
  } else {
    return(b);
  }
}
/* вариант с ? :
function min(a, b) {
  return a < b ? a : b;
}

function pow(x, n) {
  n <= 1;
return(Math.pow(x, n));
}


function fib(n) {
    if (n == 1) {
      return 0;
    } else if (n == 2) {
      return 1;
    } else {
      fib(n-1) + fib(n-2)
    }
}

function leo(n) {
  if (n == 0 || n == 1) {
  return 1;
  } else {
  return leo(n-1) + leo(n-2) + 1;
  }
}

function g() { return 1; }

alert(g);

var i = 0;
do {
  i++;
  alert(i);
} while (i < 3);

function factorial(n) {
  if(n == 1) {
    return 1;
  } else {
    return factorial(n-1) * n;
  }
}
*/
// контекст зона видемости
/*window.onload = function () {

  var item = document.querySelector('.items .item');

  item.onclick = activeItem;

}

function activeItem() {
  this.classList.toggle('item-active'); // события, ссылается на событие на какой-либо предмет

// контекст this
  window.onload = function () {

    var items = document.querySelectorAll('.items .item');
    for (var i = 0; i < items.length; i++) {
      items[i].onclick = activeItem;
    }
  /*  item.onclick = function () {
    this.classList.toggle('item-active');
    }

      function activeItem() {
        this.classList.toggle('item-active');
    //  console.log(item);
    }
  }
}

// замыкания не отличается от зоны видемости, видет все родительские методы
переменная объявленная вне функции.
window.onload = function () {

  var item = document.querySelector('.items .item');

  item.onclick = activeItem;
  }
/*  item.onclick = function () {
  this.classList.toggle('item-active');
  }

    function activeItem() {
      //this.classList.toggle('item-active');
      console.log(item);
  }
}

window.onload = function () {

  var items = document.querySelectorAll('.items .item');

/*  for (var i = 0; i < items.length; i++) {
    items[i].onclick = activeItem;
  }

    function activeItem() {
      this.classList.toggle('item-active');

  }
  setInterval(function () {
    var rand = mtRand(0, items.length - 1);
  //  console.log(rand);
  activeItem.call(items[rand]);
    }, 500);


}
function mtRand(min, max) {
  return Math.floor(Math.random() * (max - min + 1));
}
*/

// коллбеки - это следующие действия
window.onload = function () {

  var items = document.querySelectorAll('.items .item');

 for (var i = 0; i < items.length; i++) {
    items[i].onclick = function () {
      fade(this, 1000, function () {
        this.style.display = 'none';
      });
    }
  }
}
    function fade(elem, t, f) {
      var fps = 50;
      var time = t || 500;
      var steps = time / fps;
      var op = 1;
      var d0 = op / steps;

      var callback = f || function () {};

      var timer = setInterval(function () {
        op -= d0;
        elem.style.opacity = op;
        steps--;

        if (steps === 0) {
           clearInterval(timer);
           callback.call(elem);
        }
      }, (1000 / fps));
  //    this.classList.toggle('item-active');

  }
/*  setInterval(function () {
    var rand = mtRand(0, items.length - 1);
  //  console.log(rand);
  activeItem.call(items[rand]);
    }, 500);
}
function mtRand(min, max) {
  return Math.floor(Math.random() * (max - min + 1));
}
*/
