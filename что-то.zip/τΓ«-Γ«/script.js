/*alert("Hi!");
alert('Hello');
alert( null || 2 && 3 || 4 );
 var key = prompt("Ключ!?", "");
if (key > 0) {
  alert('Верно!');
} else if (key < 0) {
  alert('Не верно! '+ prompt("Ключ!?"));
} else {
  alert('Ключ!!!');
}

var login = prompt("Введите логин?", "");

var message = (login == "Вася") ? 'Привет!' :
  (login == "Директор") ? 'Здравствуйте!' :
  (login == "") ? 'Нет логина' : "";
alert(message);

function checkAge(age) {
  age > 18 ? return true || age < 18 ? return confirm('Родители разрешили?');
}
/* можно и одтельно использовать ? и || напирмер:
 function checkAge(age) {
  return (age > 18) ? true : confirm('Родители разрешили?');
};

function checkAge(age) {
  return (age > 18) || confirm('Родители разрешили?');
};
*/
/*
var age = 0;
if (age >= 14 || age <= 90) {
  alert("ghbd")
}
var sum = 0;

while (true) {

  var value = +prompt("Введите число", '');

  if (!value) break; // (*)

  sum += value;

}
alert( 'Сумма: ' + sum );

var number = 100;
while (true) {
  var numberLead = prompt("Видите число больше 100", 0);

  if (numberLead <= 100 && numberLead != null) {
    numberLead;
  } else {
    break;
  }
}

var browser = prompt("Какой вы используете браузер?", "");
if (browser == "IE") {
  alert("О, да у вас IE!");
} else if (browser == "Chrome"
          || browser == "Firefox"
          || browser == "Safari"
          || browser == "Opera") {
  alert("Да, и эти браузеры мы поддерживаем");
} else {
  alert('Мы надеемся, что и в вашем браузере все ок!');
}

var a = +prompt("a?", "");
switch (a) {
  case 0:
    alert(0);
    break;

  case 1:
    alert(1);
    break;

  case 2:
  case 3:
    alert("2,3")
    break;
}

(function () {
  var elems = document.getElementsByTagName("p");
    classElems = document.getElementsByClassName("paragraph"),
    idElems = document.getElementById("three"),
    elemsSelector = document.querySelector("p"),
    elemsSelectorAll = document.querySelectorAll("p"),
    elemsInDiv = document.querySelectorAll("div p");
    idElemsSelector =document.querySelector("#three");
//    console.log( classElems );
//    console.log( idElems );
//    console.log( elems );
//    console.log( elemsSelector );
//    console.log( elemsSelectorAll );
//    console.log(  elemsInDiv );
//    console.log( idElemsSelector );
for (var i = 0; i < elems.length; i++) {
//    console.log( elems[i].tagName );
//    console.log( elems[i].parentNode );
//    console.log( elems[i].previousSibling.previousSibling );
//    console.log( elems[i].nextSibling.nextSibling );
//    console.log( elems[i].previousSibling.nodeName );
//    console.log( elems[i].nodeType );
//    console.log( elems[i].previousSibling.nodeType );

/* if (elems[i].nodeType === 1) {
     console.log ( "Это узел элемента" );

  } if (elems[i].previousSibling.nodeType === 3) {
    console.log( "Это текстовый узел" );
  л
    }
console.log( document.querySelector("div").childNodes );
console.log( document.querySelector("div").children );

console.log( document.querySelector("div").lastChild );
console.log( document.querySelector("div").firstChild );

console.log( document.querySelector("div").innerHTML );

})();
свойство события медоды
*/
/*var t = document.querySelector('#gallery');
t.onclick = function () {
 t.innerHTML = "Почему не меняется класс?";
 t.className = 'three';
 t.style.color = "grey";
 t.style.fontSize = "25px";
    }

var btn_prev = document.querySelector('#gallery .buttons .prev');
var btn_next = document.querySelector('#gallery .buttons .next');

var images = document.querySelectorAll("#gallery .photos img");
var i = 0;

btn_prev.onclick = function () {
  images[i].className = "";
  i--;
  if (i < 0) {
    i = images.length - 1;
  }
  images[i].className = "showed";
}

btn_next.onclick = function () {
  images[i].className = "";
  i++;
  if (i >= images.length) {
    i = 0;
  }
  images[i].className = "showed";
}
*/
